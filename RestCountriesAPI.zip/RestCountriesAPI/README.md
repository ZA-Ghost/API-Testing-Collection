# REST Countries API — Full Automation Suite

A layered REST API test suite built with **REST Assured** and **TestNG**
that validates the [REST Countries v3.1 API](https://restcountries.com/)
across schema validation, data integrity, region filtering, language
lookup, currency lookup, and negative error handling — all reported in
a rich Extent HTML report.

---

## 📋 Project Overview

This suite goes beyond basic status code checks. Every endpoint is tested
for structure (JSON Schema), content (field values), filtering accuracy
(every result matches the query), and error handling (404 for invalid input).
Responses are deserialised into typed Java model objects so tests read
cleanly without raw Map casts.

---

## 🏗️ Project Structure

```
src/
└── test/
    ├── java/
    │   ├── base/
    │   │   └── BaseTest.java               # RequestSpec + ResponseSpec setup
    │   ├── clients/
    │   │   └── CountryClient.java          # All HTTP calls in one place
    │   ├── data/
    │   │   ├── Endpoints.java              # All API paths and schema file paths
    │   │   └── TestData.java               # Country names, codes, expected values
    │   ├── listeners/
    │   │   └── ExtentReportListener.java   # TestNG → Extent HTML report
    │   ├── models/
    │   │   └── Country.java                # Typed response model (Jackson)
    │   ├── tests/
    │   │   ├── SchemaValidationTest.java   # JSON Schema validation — 3 tests
    │   │   ├── CountryDataTest.java        # Field value assertions — 11 tests
    │   │   ├── RegionTest.java             # Region + subregion — 8 tests
    │   │   ├── LanguageTest.java           # Language endpoint — 8 tests
    │   │   ├── CurrencyTest.java           # Currency endpoint — 7 tests
    │   │   └── NegativeTest.java           # 404 error handling — 7 tests
    │   └── utils/
    │       ├── ExtentReportManager.java    # Singleton report instance
    │       └── ResponseLogger.java         # Logs request/response to report
    └── resources/
        └── schemas/
            ├── all-names-schema.json       # Schema for /all?fields=name
            └── single-country-schema.json  # Schema for single country response
testng.xml
pom.xml
```

---

## ✅ Test Scenarios

### `SchemaValidationTest` — JSON Schema (3 tests)
| # | Test | What it validates |
|---|---|---|
| 1 | `testAllNamesSchemaValidation` | Every country has name.common and name.official string fields |
| 2 | `testSingleCountrySchemaValidation` | Single country response has all required top-level fields |
| 3 | `testRegionResponseSchemaValidation` | Region response array matches the names schema |

### `CountryDataTest` — Field Values (11 tests)
| # | Test | What it validates |
|---|---|---|
| 1 | `testTotalCountryCountIs195` | /all returns exactly 195 countries |
| 2 | `testSouthAfricaBasicData` | Name, region, and subregion are correct |
| 3 | `testSouthAfricaCapital` | Capital includes Pretoria |
| 4 | `testSouthAfricaPopulation` | Population > 50 million |
| 5 | `testSouthAfricaCurrency` | Uses ZAR |
| 6 | `testSouthAfricanSignLanguageInNativeName` | sasl key present in nativeName |
| 7 | `testGermanyData` | Capital Berlin, region Europe |
| 8 | `testGermanyCurrency` | Uses EUR |
| 9 | `testJapanData` | Capital Tokyo, region Asia |
| 10 | `testCountryLookupByCodeZA` | Code ZA returns South Africa |
| 11 | `testCountryLookupByCodeDE` | Code DE returns Germany |

### `RegionTest` — Region & Subregion (8 tests)
| # | Test | What it validates |
|---|---|---|
| 1 | `testAfricaRegionReturnsCountries` | Non-empty list for Africa |
| 2 | `testAllAfricaCountriesHaveCorrectRegion` | Every result has region = Africa |
| 3 | `testSouthAfricaInAfricaRegion` | South Africa present |
| 4 | `testNigeriaInAfricaRegion` | Nigeria present |
| 5 | `testEuropeRegionReturnsCountries` | Non-empty list for Europe |
| 6 | `testGermanyInEuropeRegion` | Germany present |
| 7 | `testSouthernAfricaSubregion` | Every result has subregion = Southern Africa |
| 8 | `testJapanInAsiaRegion` | Japan in Asia region |

### `LanguageTest` — Language Endpoint (8 tests)
| # | Test | What it validates |
|---|---|---|
| 1 | `testZuluLanguageReturnsCountries` | Non-empty list for Zulu (zul) |
| 2 | `testSouthAfricaInZuluLanguage` | South Africa in Zulu results |
| 3 | `testSouthAfricaInAfrikaansLanguage` | South Africa in Afrikaans results |
| 4 | `testAllGermanCountriesSpeakGerman` | Every German result lists deu |
| 5 | `testGermanyInGermanLanguage` | Germany in German results |
| 6 | `testJapanInJapaneseLanguage` | Japan in Japanese results |
| 7 | `testBrazilInPortugueseLanguage` | Brazil in Portuguese results |
| 8 | `testSouthAfricaHas11OfficialLanguages` | At least 11 official languages |

### `CurrencyTest` — Currency Endpoint (7 tests)
| # | Test | What it validates |
|---|---|---|
| 1 | `testZARCurrencyReturnsCountries` | Non-empty list for ZAR |
| 2 | `testSouthAfricaInZARCurrency` | South Africa in ZAR results |
| 3 | `testAllZARCountriesHaveZARCurrency` | Every ZAR result lists ZAR |
| 4 | `testGermanyInEURCurrency` | Germany in EUR results |
| 5 | `testEURUsedByMoreThan10Countries` | EUR used by 10+ countries |
| 6 | `testJapanInJPYCurrency` | Japan in JPY results |
| 7 | `testZARCurrencyHasNameAndSymbol` | ZAR data has name and symbol fields |

### `NegativeTest` — Error Handling (7 tests)
| # | Test | What it validates |
|---|---|---|
| 1 | `testInvalidCountryNameReturns404` | Invalid name → 404 |
| 2 | `testInvalidCountryCodeReturns404` | Invalid code → 404 |
| 3 | `testInvalidRegionReturns404` | Invalid region → 404 |
| 4 | `testInvalidLanguageCodeReturns404` | Invalid language → 404 |
| 5 | `testInvalidCurrencyCodeReturns404` | Invalid currency → 404 |
| 6 | `testEmptyNameSearchDoesNotReturn200` | Empty search → not 200 |
| 7 | `test404ResponseBodyContainsStatusField` | Error body has status: 404 |

**Total: 44 tests**

---

## 🛠️ Tools & Technologies

| Tool | Version | Purpose |
|---|---|---|
| **Java** | 21 | Core programming language |
| **REST Assured** | 5.4.0 | HTTP client and fluent assertion library |
| **REST Assured JSON Schema Validator** | 5.4.0 | JSON Schema validation |
| **TestNG** | 7.11.0 | Test framework, assertions, listeners |
| **ExtentReports** | 5.1.2 | HTML test report generation |
| **Jackson Databind** | 2.17.1 | JSON → typed Java model deserialisation |
| **Apache Commons IO** | 2.15.1 | Report directory handling |
| **Maven** | — | Dependency management and build |

---

## 💡 Concepts Demonstrated

- **Layered architecture** — base, client, data, model, listener, utils,
  and test layers are fully separated with single responsibilities
- **RequestSpecification / ResponseSpecification** — base URL, headers,
  and logging configured once in `BaseTest` and inherited by all tests
- **`CountryClient`** — all HTTP calls centralised; tests never call
  `RestAssured.given()` directly
- **JSON Schema validation** — schema files in `src/test/resources/schemas/`
  validated with `matchesJsonSchemaInClasspath()` — structural contract testing
- **Typed model deserialisation** — `.extract().as(Country[].class)` replaces
  raw `Map<String, Object>` chains throughout
- **Filtering accuracy tests** — not just "did it return something" but
  "does every result match the filter" (region, language, currency)
- **Negative testing** — 404 responses and error body structure validated
  for every endpoint that accepts user input
- **ExtentReports + ITestListener** — pass/fail/skip logged with
  request URL, status code, and truncated response body per test
- **`TestData` and `Endpoints` constants** — no hardcoded strings in
  test classes; one file to update if values change
- **`ResponseLogger`** — formats and embeds request/response details
  into the HTML report so it is self-contained and reviewable

---

## 🚀 How to Run

### Prerequisites
- Java 21+
- Maven

### Run all 44 tests
```bash
mvn test
```

### Run a single test class
```bash
mvn test -Dtest=NegativeTest
mvn test -Dtest=CountryDataTest
mvn test -Dtest=RegionTest
```

### View the report
Open in any browser after the run:
```
reports/ExtentReport.html
```

> The report is only generated when tests run through Maven or the
> testng.xml suite file. Running individual classes from IntelliJ's
> play button bypasses the listener. To use the play button, go to
> **Run → Edit Configurations → Test kind: Suite** and point it at
> `testng.xml`.
