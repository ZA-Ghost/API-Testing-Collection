package base;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.testng.annotations.BeforeClass;

/**
 * BaseTest is the parent class for all API test classes.
 *
 * It configures two REST Assured specifications shared across every test:
 *
 *   RequestSpecification  — base URL, content type, and request logging
 *   ResponseSpecification — response logging applied to every response
 *
 * Using specifications means individual test methods never repeat
 * base URL setup or content-type headers. Any change to the API base
 * URL or common headers is made in one place here.
 *
 * RestAssured.requestSpecification and RestAssured.responseSpecification
 * are static — once set in @BeforeClass they apply to every
 * RestAssured call in the subclass without being passed explicitly.
 */
public class BaseTest {

    /** The base URL of the REST Countries v3.1 API */
    protected static final String BASE_URL = "https://restcountries.com/v3.1";

    /**
     * Runs once before any tests in the class execute.
     *
     * Builds and assigns the shared request and response specifications.
     * Logging is set to ALL so every request and response is printed
     * to the console — useful for debugging failures.
     */
    @BeforeClass
    public void setUp() {

        // ── Request specification ─────────────────────────────────────────
        RequestSpecification requestSpec = new RequestSpecBuilder()
                .setBaseUri(BASE_URL)               // All requests start from this URL
                .setContentType(ContentType.JSON)   // Accept and send JSON by default
                .log(LogDetail.ALL)                 // Log full request details to console
                .build();

        // ── Response specification ────────────────────────────────────────
        ResponseSpecification responseSpec = new ResponseSpecBuilder()
                .log(LogDetail.ALL)                 // Log full response details to console
                .build();

        // Assign globally so all RestAssured calls in subclasses inherit them
        RestAssured.requestSpecification  = requestSpec;
        RestAssured.responseSpecification = responseSpec;
    }
}
