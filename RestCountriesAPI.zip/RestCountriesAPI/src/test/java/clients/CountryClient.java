package clients;

import data.Endpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;

/**
 * CountryClient is the API client layer for the REST Countries suite.
 *
 * Every HTTP call to the REST Countries API goes through this class.
 * Test classes never call RestAssured directly — they call methods here.
 *
 * This separation means:
 *   - If the API URL structure changes, only this file needs updating
 *   - Test classes read like business scenarios, not HTTP plumbing
 *   - The same request can be reused across multiple test classes
 *
 * All methods return a raw REST Assured Response object so the caller
 * can assert the status code, extract the body, or validate the schema
 * as needed for their specific test scenario.
 */
public class CountryClient {

    // ── All countries ──────────────────────────────────────────────────────

    /**
     * GET /all — returns all countries with all fields.
     */
    public Response getAllCountries() {
        return RestAssured
                .given()
                .when()
                .get(Endpoints.ALL);
    }

    /**
     * GET /all?fields=name — returns all countries with name field only.
     * Used for count assertions and schema validation.
     */
    public Response getAllCountryNames() {
        return RestAssured
                .given()
                .when()
                .get(Endpoints.ALL_NAMES);
    }

    /**
     * GET /all?fields=name,capital,region,... — returns all countries
     * with the standard set of fields used across most tests.
     */
    public Response getAllCountriesWithFields() {
        return RestAssured
                .given()
                .when()
                .get(Endpoints.ALL_FIELDS);
    }

    // ── Search by name ─────────────────────────────────────────────────────

    /**
     * GET /name/{name} — searches for countries by name (partial match).
     *
     * @param name The country name to search for (e.g. "south africa")
     */
    public Response getCountryByName(String name) {
        return RestAssured
                .given()
                .when()
                .get(Endpoints.BY_NAME + name);
    }

    /**
     * GET /name/{name}?fullText=true — exact full name match only.
     *
     * @param name The exact country name to search for
     */
    public Response getCountryByFullName(String name) {
        return RestAssured
                .given()
                .when()
                .get(String.format(Endpoints.BY_FULL_NAME, name));
    }

    /**
     * GET /name/{name}?fields=name,languages — returns name and languages
     * for a country. Used for language-specific assertions.
     *
     * @param name The country name to search for
     */
    public Response getCountryNameAndLanguages(String name) {
        return RestAssured
                .given()
                .when()
                .get(Endpoints.BY_NAME + name + "?fields=name,languages");
    }

    // ── Search by code ─────────────────────────────────────────────────────

    /**
     * GET /alpha/{code} — searches by ISO 3166-1 alpha-2 or alpha-3 code.
     *
     * @param code The country code (e.g. "ZA", "DEU")
     */
    public Response getCountryByCode(String code) {
        return RestAssured
                .given()
                .when()
                .get(Endpoints.BY_CODE + code);
    }

    // ── Search by region ───────────────────────────────────────────────────

    /**
     * GET /region/{region} — returns all countries in a region.
     *
     * @param region The region name (e.g. "Africa", "Europe")
     */
    public Response getCountriesByRegion(String region) {
        return RestAssured
                .given()
                .when()
                .get(Endpoints.BY_REGION + region);
    }

    /**
     * GET /subregion/{subregion} — returns all countries in a subregion.
     *
     * @param subregion The subregion name (e.g. "Southern Africa")
     */
    public Response getCountriesBySubregion(String subregion) {
        return RestAssured
                .given()
                .when()
                .get(Endpoints.BY_SUBREGION + subregion);
    }

    // ── Search by language ─────────────────────────────────────────────────

    /**
     * GET /lang/{language} — returns all countries where a language is spoken.
     *
     * @param languageCode The ISO 639-3 language code (e.g. "zul", "deu")
     */
    public Response getCountriesByLanguage(String languageCode) {
        return RestAssured
                .given()
                .when()
                .get(Endpoints.BY_LANGUAGE + languageCode);
    }

    // ── Search by currency ─────────────────────────────────────────────────

    /**
     * GET /currency/{currency} — returns all countries using a currency.
     *
     * @param currencyCode The ISO 4217 currency code (e.g. "ZAR", "EUR")
     */
    public Response getCountriesByCurrency(String currencyCode) {
        return RestAssured
                .given()
                .when()
                .get(Endpoints.BY_CURRENCY + currencyCode);
    }
}
