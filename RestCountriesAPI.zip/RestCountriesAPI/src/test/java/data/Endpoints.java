package data;

/**
 * Endpoints is a central store of all REST Countries API endpoint paths.
 *
 * Every test class references constants from here instead of hardcoding
 * URL strings. If the API version or a path changes, only this file
 * needs updating.
 *
 * Paths are relative to the BASE_URL set in BaseTest — they do not
 * include the host or version prefix.
 */
public class Endpoints {

    // ── All countries ──────────────────────────────────────────────────────

    /** Returns all countries with all fields */
    public static final String ALL                  = "/all";

    /** Returns all countries — name field only */
    public static final String ALL_NAMES            = "/all?fields=name";

    /** Returns all countries — selected fields for general use */
    public static final String ALL_FIELDS           = "/all?fields=name,capital,region,subregion,population,area,languages,currencies,flags";

    // ── Search by name ─────────────────────────────────────────────────────

    /** Search by country name — append the name as a path segment */
    public static final String BY_NAME              = "/name/";

    /** Full name search — exact match only */
    public static final String BY_FULL_NAME         = "/name/%s?fullText=true";

    // ── Search by code ─────────────────────────────────────────────────────

    /** Search by ISO 3166-1 alpha-2 or alpha-3 country code */
    public static final String BY_CODE              = "/alpha/";

    // ── Search by region ───────────────────────────────────────────────────

    /** Returns all countries in a given region (e.g. Africa, Europe) */
    public static final String BY_REGION            = "/region/";

    /** Returns all countries in a given subregion */
    public static final String BY_SUBREGION         = "/subregion/";

    // ── Search by language ─────────────────────────────────────────────────

    /** Returns all countries where a given language is spoken */
    public static final String BY_LANGUAGE          = "/lang/";

    // ── Search by currency ─────────────────────────────────────────────────

    /** Returns all countries that use a given currency */
    public static final String BY_CURRENCY          = "/currency/";

    // ── Schema file paths ──────────────────────────────────────────────────

    /** JSON Schema file for the /all?fields=name response */
    public static final String SCHEMA_ALL_NAMES     = "schemas/all-names-schema.json";

    /** JSON Schema file for a single country object */
    public static final String SCHEMA_SINGLE_COUNTRY = "schemas/single-country-schema.json";

    // Private constructor — this class is a constants holder, not instantiated
    private Endpoints() {}
}
