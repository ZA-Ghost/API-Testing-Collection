package data;

/**
 * TestData is a central store of all country names, codes, regions,
 * languages, and expected values used across the test suite.
 *
 * Keeping test data here means that if a country's data changes in
 * the API (e.g. a capital moves, a currency changes) there is one
 * file to update — not scattered strings across every test class.
 */
public class TestData {

    // ── Country names ──────────────────────────────────────────────────────
    public static final String SOUTH_AFRICA     = "south africa";
    public static final String SOUTH_AFRICA_FULL = "South Africa";
    public static final String GERMANY          = "germany";
    public static final String JAPAN            = "japan";
    public static final String BRAZIL           = "brazil";
    public static final String FRANCE           = "france";
    public static final String AUSTRALIA        = "australia";
    public static final String NIGERIA          = "nigeria";
    public static final String INVALID_COUNTRY  = "xyzinvalidcountry999";

    // ── Country codes ──────────────────────────────────────────────────────
    public static final String CODE_ZA          = "ZA";   // South Africa
    public static final String CODE_DE          = "DE";   // Germany
    public static final String CODE_JP          = "JP";   // Japan
    public static final String CODE_BR          = "BR";   // Brazil
    public static final String CODE_INVALID     = "XX";   // Invalid code

    // ── Regions and subregions ─────────────────────────────────────────────
    public static final String REGION_AFRICA    = "Africa";
    public static final String REGION_EUROPE    = "Europe";
    public static final String REGION_ASIA      = "Asia";
    public static final String REGION_AMERICAS  = "Americas";
    public static final String REGION_INVALID   = "InvalidRegion999";

    public static final String SUBREGION_SOUTHERN_AFRICA  = "Southern Africa";
    public static final String SUBREGION_WESTERN_EUROPE   = "Western Europe";

    // ── Languages ──────────────────────────────────────────────────────────
    public static final String LANGUAGE_ZUL     = "zul";  // Zulu
    public static final String LANGUAGE_AFR     = "afr";  // Afrikaans
    public static final String LANGUAGE_DEU     = "deu";  // German
    public static final String LANGUAGE_JPN     = "jpn";  // Japanese
    public static final String LANGUAGE_POR     = "por";  // Portuguese
    public static final String LANGUAGE_INVALID = "xxx";  // Invalid language code

    // ── Currencies ─────────────────────────────────────────────────────────
    public static final String CURRENCY_ZAR     = "ZAR";  // South African Rand
    public static final String CURRENCY_EUR     = "EUR";  // Euro
    public static final String CURRENCY_JPY     = "JPY";  // Japanese Yen
    public static final String CURRENCY_INVALID = "XXX";  // Invalid currency code

    // ── Expected values ────────────────────────────────────────────────────
    public static final int    EXPECTED_COUNTRY_COUNT       = 195;
    public static final String SOUTH_AFRICA_CAPITAL         = "Pretoria";
    public static final String SOUTH_AFRICA_REGION          = "Africa";
    public static final String SOUTH_AFRICA_SUBREGION       = "Southern Africa";
    public static final String SOUTH_AFRICA_SIGN_LANG_CODE  = "sasl";
    public static final String GERMANY_CAPITAL              = "Berlin";
    public static final String GERMANY_REGION               = "Europe";
    public static final String JAPAN_CAPITAL                = "Tokyo";
    public static final String JAPAN_REGION                 = "Asia";

    // ── HTTP status codes ──────────────────────────────────────────────────
    public static final int STATUS_OK           = 200;
    public static final int STATUS_NOT_FOUND    = 404;

    public static final String BASE_URL = "https://restcountries.com";
    // Private constructor — constants holder, not instantiated
    private TestData() {}
}
