package listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import utils.ExtentReportManager;

/**
 * ExtentReportListener is a TestNG ITestListener that hooks into the
 * test lifecycle and logs every result into the Extent HTML report.
 *
 * Registered in testng.xml — no changes to test classes are needed.
 *
 * Events handled:
 *   onTestStart   — creates a new test entry in the report
 *   onTestSuccess — marks it PASS (green)
 *   onTestFailure — marks it FAIL (red) and logs the exception
 *   onTestSkipped — marks it SKIP (orange)
 *   onFinish      — flushes all results to the HTML file
 *
 * ThreadLocal<ExtentTest> ensures parallel test execution does not
 * mix up report entries between threads.
 */
public class ExtentReportListener implements ITestListener {

    private static final ExtentReports        extent     = ExtentReportManager.getInstance();
    private static final ThreadLocal<ExtentTest> testEntry = new ThreadLocal<>();

    /**
     * Fires when a test method begins.
     * Creates a named report entry for this test.
     */
    @Override
    public void onTestStart(ITestResult result) {
        ExtentTest test = extent.createTest(
                result.getMethod().getMethodName(),
                result.getMethod().getDescription()
        );
        testEntry.set(test);
    }

    /**
     * Fires when a test passes.
     * Logs a green PASS label.
     */
    @Override
    public void onTestSuccess(ITestResult result) {
        testEntry.get().pass(
                MarkupHelper.createLabel("PASSED", ExtentColor.GREEN)
        );
    }

    /**
     * Fires when a test fails.
     * Logs a red FAIL label and the full exception message.
     */
    @Override
    public void onTestFailure(ITestResult result) {
        testEntry.get().fail(
                MarkupHelper.createLabel("FAILED", ExtentColor.RED)
        );
        testEntry.get().fail(result.getThrowable());
    }

    /**
     * Fires when a test is skipped.
     * Logs an orange SKIP label.
     */
    @Override
    public void onTestSkipped(ITestResult result) {
        testEntry.get().skip(
                MarkupHelper.createLabel("SKIPPED", ExtentColor.ORANGE)
        );
    }

    /**
     * Fires after all tests complete.
     * Flushes buffered results to the HTML file — without this the
     * report file will be empty or incomplete.
     */
    @Override
    public void onFinish(ITestContext context) {
        if (extent != null) {
            extent.flush();
        }
    }

    /**
     * Returns the ExtentTest entry for the current thread.
     * Called by test classes to log request/response details inline.
     *
     * @return The active ExtentTest for this thread
     */
    public static ExtentTest getTest() {
        return testEntry.get();
    }
}
