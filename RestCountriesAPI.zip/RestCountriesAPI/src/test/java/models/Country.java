package models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import java.util.Map;

/**
 * Country is a Java model that represents a single country object
 * returned by the REST Countries API.
 *
 * Jackson's @JsonIgnoreProperties(ignoreUnknown = true) means that
 * fields present in the API response but not declared here are
 * silently ignored — the model only captures what the tests need.
 *
 * Used with REST Assured's .as(Country[].class) or .as(Country.class)
 * to deserialise the JSON response body directly into typed objects,
 * replacing raw Map<String, Object> casts throughout the tests.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Country {

    /** The name object containing common, official, and nativeName fields */
    private Name name;

    /** The capital city or cities (some countries have multiple) */
    private List<String> capital;

    /** The continental region (e.g. "Africa", "Europe") */
    private String region;

    /** The more specific subregion (e.g. "Southern Africa", "Western Europe") */
    private String subregion;

    /** Population count */
    private long population;

    /** Total land area in km² */
    private double area;

    /**
     * Languages spoken — key is the ISO 639-3 language code,
     * value is the English name of the language.
     * e.g. { "zul": "Zulu", "afr": "Afrikaans" }
     */
    private Map<String, String> languages;

    /**
     * Currencies used — key is the ISO 4217 currency code,
     * value is an object with "name" and "symbol" fields.
     * e.g. { "ZAR": { "name": "South African rand", "symbol": "R" } }
     */
    private Map<String, Map<String, String>> currencies;

    /** Flag image URLs — "png" and "svg" keys */
    private Map<String, String> flags;

    /** ISO 3166-1 alpha-2 two-letter country code (e.g. "ZA") */
    private String cca2;

    /** ISO 3166-1 alpha-3 three-letter country code (e.g. "ZAF") */
    private String cca3;

    // ── Getters ────────────────────────────────────────────────────────────

    public Name getName()                                    { return name; }
    public List<String> getCapital()                         { return capital; }
    public String getRegion()                                { return region; }
    public String getSubregion()                             { return subregion; }
    public long getPopulation()                              { return population; }
    public double getArea()                                  { return area; }
    public Map<String, String> getLanguages()                { return languages; }
    public Map<String, Map<String, String>> getCurrencies()  { return currencies; }
    public Map<String, String> getFlags()                    { return flags; }
    public String getCca2()                                  { return cca2; }
    public String getCca3()                                  { return cca3; }

    // ── Setters ────────────────────────────────────────────────────────────

    public void setName(Name name)                                          { this.name = name; }
    public void setCapital(List<String> capital)                            { this.capital = capital; }
    public void setRegion(String region)                                    { this.region = region; }
    public void setSubregion(String subregion)                              { this.subregion = subregion; }
    public void setPopulation(long population)                              { this.population = population; }
    public void setArea(double area)                                        { this.area = area; }
    public void setLanguages(Map<String, String> languages)                 { this.languages = languages; }
    public void setCurrencies(Map<String, Map<String, String>> currencies)  { this.currencies = currencies; }
    public void setFlags(Map<String, String> flags)                         { this.flags = flags; }
    public void setCca2(String cca2)                                        { this.cca2 = cca2; }
    public void setCca3(String cca3)                                        { this.cca3 = cca3; }

    /**
     * Name is a nested model representing the name object inside a country.
     *
     * Fields:
     *   common     — the everyday name (e.g. "South Africa")
     *   official   — the full official name (e.g. "Republic of South Africa")
     *   nativeName — a map of native names keyed by language code
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Name {

        private String common;
        private String official;

        /**
         * Native names keyed by ISO 639-3 language code.
         * Each value is a map with "official" and "common" keys.
         * e.g. { "zul": { "official": "...", "common": "iNingizimu Afrika" } }
         */
        private Map<String, Map<String, String>> nativeName;

        public String getCommon()                                         { return common; }
        public String getOfficial()                                       { return official; }
        public Map<String, Map<String, String>> getNativeName()           { return nativeName; }

        public void setCommon(String common)                              { this.common = common; }
        public void setOfficial(String official)                          { this.official = official; }
        public void setNativeName(Map<String, Map<String, String>> n)    { this.nativeName = n; }
    }
}
