package tests;

import base.BaseTest;
import clients.CountryClient;
import data.Endpoints;
import data.TestData;
import io.restassured.response.Response;
import listeners.ExtentReportListener;
import models.Country;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import utils.ResponseLogger;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * CountryDataTest validates the data content of REST Countries API responses.
 *
 * Tests in this class assert specific field values — country names,
 * capitals, regions, populations, languages, and currencies — rather
 * than structural schema compliance.
 *
 * Responses are deserialised into typed Country model objects using
 * Jackson, replacing raw Map<String, Object> casts with clean field
 * access like country.getCapital() and country.getRegion().
 */
public class CountryDataTest extends BaseTest {

    private CountryClient client;

    @BeforeClass
    public void init() {
        client = new CountryClient();
    }

    // ── Country count ──────────────────────────────────────────────────────

    /**
     * Test 1: The /all endpoint returns exactly 195 countries.
     */
    @Test(description = "All countries endpoint returns exactly 195 countries")
    public void testTotalCountryCountIs195() {
        Response response = client.getAllCountryNames();

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.ALL_NAMES, response);

        List<?> countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(List.class);

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Countries returned: " + countries.size());

        Assert.assertEquals(countries.size(), TestData.EXPECTED_COUNTRY_COUNT,
                "Expected " + TestData.EXPECTED_COUNTRY_COUNT + " countries but got " + countries.size());
    }

    // ── South Africa ───────────────────────────────────────────────────────

    /**
     * Test 2: South Africa's common name, region, and subregion are correct.
     */
    @Test(description = "South Africa returns correct name, region, and subregion")
    public void testSouthAfricaBasicData() {
        Response response = client.getCountryByName(TestData.SOUTH_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_NAME + TestData.SOUTH_AFRICA, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        Assert.assertTrue(countries.length > 0, "No country data returned for South Africa.");

        Country za = countries[0];

        Assert.assertEquals(za.getName().getCommon(), TestData.SOUTH_AFRICA_FULL,
                "South Africa common name mismatch.");
        Assert.assertEquals(za.getRegion(), TestData.SOUTH_AFRICA_REGION,
                "South Africa region mismatch.");
        Assert.assertEquals(za.getSubregion(), TestData.SOUTH_AFRICA_SUBREGION,
                "South Africa subregion mismatch.");

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Common: " + za.getName().getCommon()
                + " | Region: " + za.getRegion()
                + " | Subregion: " + za.getSubregion());
    }

    /**
     * Test 3: South Africa's capital is Pretoria.
     */
    @Test(description = "South Africa capital is Pretoria")
    public void testSouthAfricaCapital() {
        Response response = client.getCountryByName(TestData.SOUTH_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_NAME + TestData.SOUTH_AFRICA, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        Country za = countries[0];

        Assert.assertNotNull(za.getCapital(), "South Africa capital list is null.");
        Assert.assertTrue(za.getCapital().contains(TestData.SOUTH_AFRICA_CAPITAL),
                "Expected capital '" + TestData.SOUTH_AFRICA_CAPITAL
                + "' not found. Actual: " + za.getCapital());

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Capital(s): " + za.getCapital());
    }

    /**
     * Test 4: South Africa's population is greater than 50 million.
     */
    @Test(description = "South Africa population is greater than 50 million")
    public void testSouthAfricaPopulation() {
        Response response = client.getCountryByName(TestData.SOUTH_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_NAME + TestData.SOUTH_AFRICA, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        long population = countries[0].getPopulation();

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Population: " + population);

        Assert.assertTrue(population > 50_000_000,
                "South Africa population should be > 50 million. Actual: " + population);
    }

    /**
     * Test 5: South Africa uses the South African Rand (ZAR).
     */
    @Test(description = "South Africa uses South African Rand (ZAR)")
    public void testSouthAfricaCurrency() {
        Response response = client.getCountryByName(TestData.SOUTH_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_NAME + TestData.SOUTH_AFRICA, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        Map<String, Map<String, String>> currencies = countries[0].getCurrencies();

        Assert.assertNotNull(currencies, "Currency data is null.");
        Assert.assertTrue(currencies.containsKey(TestData.CURRENCY_ZAR),
                "Expected currency ZAR not found. Actual currencies: " + currencies.keySet());

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Currencies: " + currencies.keySet());
    }

    /**
     * Test 6: South African Sign Language is present in South Africa's nativeName.
     */
    @Test(description = "South African Sign Language (sasl) present in nativeName")
    public void testSouthAfricanSignLanguageInNativeName() {
        Response response = client.getCountryByName(TestData.SOUTH_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_NAME + TestData.SOUTH_AFRICA, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        Map<String, Map<String, String>> nativeNames =
                countries[0].getName().getNativeName();

        boolean hasSasl = nativeNames != null
                && nativeNames.containsKey(TestData.SOUTH_AFRICA_SIGN_LANG_CODE);

        ResponseLogger.info(ExtentReportListener.getTest(),
                "SASL present: " + hasSasl
                + " | NativeNames keys: " + (nativeNames != null ? nativeNames.keySet() : "null"));

        Assert.assertTrue(hasSasl,
                "South African Sign Language (sasl) not found in nativeName map.");
    }

    // ── Germany ────────────────────────────────────────────────────────────

    /**
     * Test 7: Germany's capital is Berlin and region is Europe.
     */
    @Test(description = "Germany capital is Berlin and region is Europe")
    public void testGermanyData() {
        Response response = client.getCountryByName(TestData.GERMANY);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_NAME + TestData.GERMANY, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        Country de = Arrays.stream(countries)
                .filter(c -> "Germany".equals(c.getName().getCommon()))
                .findFirst()
                .orElseThrow(() -> new AssertionError("Germany not found in response."));

        Assert.assertEquals(de.getRegion(), TestData.GERMANY_REGION,
                "Germany region mismatch.");
        Assert.assertTrue(de.getCapital().contains(TestData.GERMANY_CAPITAL),
                "Germany capital mismatch. Actual: " + de.getCapital());

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Capital: " + de.getCapital() + " | Region: " + de.getRegion());
    }

    /**
     * Test 8: Germany uses the Euro (EUR).
     */
    @Test(description = "Germany uses Euro (EUR)")
    public void testGermanyCurrency() {
        Response response = client.getCountryByName(TestData.GERMANY);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_NAME + TestData.GERMANY, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        Country de = Arrays.stream(countries)
                .filter(c -> "Germany".equals(c.getName().getCommon()))
                .findFirst()
                .orElseThrow(() -> new AssertionError("Germany not found."));

        Assert.assertTrue(de.getCurrencies().containsKey(TestData.CURRENCY_EUR),
                "Germany should use EUR. Actual: " + de.getCurrencies().keySet());

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Currencies: " + de.getCurrencies().keySet());
    }

    // ── Japan ──────────────────────────────────────────────────────────────

    /**
     * Test 9: Japan's capital is Tokyo and region is Asia.
     */
    @Test(description = "Japan capital is Tokyo and region is Asia")
    public void testJapanData() {
        Response response = client.getCountryByName(TestData.JAPAN);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_NAME + TestData.JAPAN, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        Country jp = countries[0];

        Assert.assertEquals(jp.getRegion(), TestData.JAPAN_REGION,
                "Japan region mismatch.");
        Assert.assertTrue(jp.getCapital().contains(TestData.JAPAN_CAPITAL),
                "Japan capital mismatch. Actual: " + jp.getCapital());

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Capital: " + jp.getCapital() + " | Region: " + jp.getRegion());
    }

    // ── Country code lookup ────────────────────────────────────────────────

    /**
     * Test 10: Lookup by ISO alpha-2 code ZA returns South Africa.
     */
    @Test(description = "ISO code ZA returns South Africa")
    public void testCountryLookupByCodeZA() {
        Response response = client.getCountryByCode(TestData.CODE_ZA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_CODE + TestData.CODE_ZA, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        Assert.assertTrue(countries.length > 0, "No country returned for code ZA.");
        Assert.assertEquals(countries[0].getName().getCommon(), TestData.SOUTH_AFRICA_FULL,
                "Code ZA should return South Africa.");

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Country returned: " + countries[0].getName().getCommon());
    }

    /**
     * Test 11: Lookup by ISO alpha-2 code DE returns Germany.
     */
    @Test(description = "ISO code DE returns Germany")
    public void testCountryLookupByCodeDE() {
        Response response = client.getCountryByCode(TestData.CODE_DE);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_CODE + TestData.CODE_DE, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        Assert.assertTrue(countries.length > 0, "No country returned for code DE.");
        Assert.assertEquals(countries[0].getName().getCommon(), "Germany",
                "Code DE should return Germany.");
    }

    private static final String BASE_URL = "https://restcountries.com/v3.1";
}
