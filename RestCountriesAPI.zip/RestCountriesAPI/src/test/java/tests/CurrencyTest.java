package tests;

import base.BaseTest;
import clients.CountryClient;
import data.Endpoints;
import data.TestData;
import io.restassured.response.Response;
import listeners.ExtentReportListener;
import models.Country;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import utils.ResponseLogger;

import java.util.Arrays;

/**
 * CurrencyTest validates the /currency/{currencyCode} endpoint.
 *
 * Tests cover:
 *   - Valid currency codes return non-empty country lists
 *   - Every country returned uses the requested currency
 *   - Specific countries are present for their expected currencies
 *   - Currency name and symbol fields are present in country data
 */
public class CurrencyTest extends BaseTest {

    private CountryClient client;

    @BeforeClass
    public void init() {
        client = new CountryClient();
    }

    /**
     * Test 1: ZAR currency endpoint returns a non-empty list.
     */
    @Test(description = "ZAR currency endpoint returns countries")
    public void testZARCurrencyReturnsCountries() {
        Response response = client.getCountriesByCurrency(TestData.CURRENCY_ZAR);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_CURRENCY + TestData.CURRENCY_ZAR, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Countries using ZAR: " + countries.length);

        Assert.assertTrue(countries.length > 0,
                "ZAR currency should return at least one country.");
    }

    /**
     * Test 2: South Africa is in the ZAR currency response.
     */
    @Test(description = "South Africa is present in ZAR currency results")
    public void testSouthAfricaInZARCurrency() {
        Response response = client.getCountriesByCurrency(TestData.CURRENCY_ZAR);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_CURRENCY + TestData.CURRENCY_ZAR, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        boolean found = Arrays.stream(countries)
                .anyMatch(c -> TestData.SOUTH_AFRICA_FULL.equals(c.getName().getCommon()));

        Assert.assertTrue(found,
                "South Africa should be present in the ZAR currency results.");
    }

    /**
     * Test 3: Every country in ZAR results actually lists ZAR in their currencies.
     */
    @Test(description = "Every country in ZAR results uses ZAR")
    public void testAllZARCountriesHaveZARCurrency() {
        Response response = client.getCountriesByCurrency(TestData.CURRENCY_ZAR);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_CURRENCY + TestData.CURRENCY_ZAR, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        for (Country country : countries) {
            Assert.assertNotNull(country.getCurrencies(),
                    country.getName().getCommon() + " has null currencies.");
            Assert.assertTrue(country.getCurrencies().containsKey(TestData.CURRENCY_ZAR),
                    country.getName().getCommon() + " does not list ZAR.");
        }
    }

    /**
     * Test 4: EUR currency returns Germany.
     */
    @Test(description = "Germany is present in EUR currency results")
    public void testGermanyInEURCurrency() {
        Response response = client.getCountriesByCurrency(TestData.CURRENCY_EUR);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_CURRENCY + TestData.CURRENCY_EUR, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Countries using EUR: " + countries.length);

        boolean found = Arrays.stream(countries)
                .anyMatch(c -> "Germany".equals(c.getName().getCommon()));

        Assert.assertTrue(found, "Germany should be present in EUR currency results.");
    }

    /**
     * Test 5: EUR is used by more than 10 countries.
     * The Eurozone currently has 20 member states.
     */
    @Test(description = "EUR is used by more than 10 countries")
    public void testEURUsedByMoreThan10Countries() {
        Response response = client.getCountriesByCurrency(TestData.CURRENCY_EUR);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_CURRENCY + TestData.CURRENCY_EUR, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        ResponseLogger.info(ExtentReportListener.getTest(),
                "EUR country count: " + countries.length);

        Assert.assertTrue(countries.length > 10,
                "EUR should be used by more than 10 countries. Actual: " + countries.length);
    }

    /**
     * Test 6: JPY currency returns Japan.
     */
    @Test(description = "Japan is present in JPY currency results")
    public void testJapanInJPYCurrency() {
        Response response = client.getCountriesByCurrency(TestData.CURRENCY_JPY);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_CURRENCY + TestData.CURRENCY_JPY, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        boolean found = Arrays.stream(countries)
                .anyMatch(c -> "Japan".equals(c.getName().getCommon()));

        Assert.assertTrue(found, "Japan should be present in JPY currency results.");
    }

    /**
     * Test 7: ZAR currency data contains name and symbol fields.
     */
    @Test(description = "ZAR currency data has name and symbol fields")
    public void testZARCurrencyHasNameAndSymbol() {
        Response response = client.getCountryByName(TestData.SOUTH_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_NAME + TestData.SOUTH_AFRICA, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        var zarDetails = countries[0].getCurrencies().get(TestData.CURRENCY_ZAR);

        Assert.assertNotNull(zarDetails, "ZAR details map is null.");
        Assert.assertNotNull(zarDetails.get("name"),
                "ZAR currency name field is missing.");
        Assert.assertNotNull(zarDetails.get("symbol"),
                "ZAR currency symbol field is missing.");

        ResponseLogger.info(ExtentReportListener.getTest(),
                "ZAR name: " + zarDetails.get("name")
                + " | symbol: " + zarDetails.get("symbol"));
    }

    private static final String BASE_URL = "https://restcountries.com/v3.1";
}
