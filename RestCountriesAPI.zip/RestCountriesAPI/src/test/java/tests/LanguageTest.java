package tests;

import base.BaseTest;
import clients.CountryClient;
import data.Endpoints;
import data.TestData;
import io.restassured.response.Response;
import listeners.ExtentReportListener;
import models.Country;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import utils.ResponseLogger;

import java.util.Arrays;

/**
 * LanguageTest validates the /lang/{languageCode} endpoint.
 *
 * Tests cover:
 *   - Valid language codes return non-empty country lists
 *   - Every country returned speaks the requested language
 *   - Specific countries are present for their primary languages
 *   - South Africa's 11 official languages are all represented
 */
public class LanguageTest extends BaseTest {

    private CountryClient client;

    @BeforeClass
    public void init() {
        client = new CountryClient();
    }

    /**
     * Test 1: Zulu (zul) language endpoint returns a non-empty list.
     */
    @Test(description = "Zulu language endpoint returns countries")
    public void testZuluLanguageReturnsCountries() {
        Response response = client.getCountriesByLanguage(TestData.LANGUAGE_ZUL);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_LANGUAGE + TestData.LANGUAGE_ZUL, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Countries speaking Zulu: " + countries.length);

        Assert.assertTrue(countries.length > 0,
                "Zulu language should return at least one country.");
    }

    /**
     * Test 2: South Africa is in the Zulu (zul) language response.
     */
    @Test(description = "South Africa is present in Zulu language results")
    public void testSouthAfricaInZuluLanguage() {
        Response response = client.getCountriesByLanguage(TestData.LANGUAGE_ZUL);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_LANGUAGE + TestData.LANGUAGE_ZUL, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        boolean found = Arrays.stream(countries)
                .anyMatch(c -> TestData.SOUTH_AFRICA_FULL.equals(c.getName().getCommon()));

        Assert.assertTrue(found,
                "South Africa should be present in the Zulu language results.");
    }

    /**
     * Test 3: South Africa is in the Afrikaans (afr) language response.
     */
    @Test(description = "South Africa is present in Afrikaans language results")
    public void testSouthAfricaInAfrikaansLanguage() {
        Response response = client.getCountriesByLanguage(TestData.LANGUAGE_AFR);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_LANGUAGE + TestData.LANGUAGE_AFR, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        boolean found = Arrays.stream(countries)
                .anyMatch(c -> TestData.SOUTH_AFRICA_FULL.equals(c.getName().getCommon()));

        Assert.assertTrue(found,
                "South Africa should be present in the Afrikaans language results.");
    }

    /**
     * Test 4: Every country returned for German (deu) actually lists German.
     */
    @Test(description = "Every country in German results speaks German")
    public void testAllGermanCountriesSpeakGerman() {
        Response response = client.getCountriesByLanguage(TestData.LANGUAGE_DEU);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_LANGUAGE + TestData.LANGUAGE_DEU, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Countries speaking German: " + countries.length);

        for (Country country : countries) {
            Assert.assertNotNull(country.getLanguages(),
                    country.getName().getCommon() + " has null languages map.");
            Assert.assertTrue(country.getLanguages().containsKey(TestData.LANGUAGE_DEU),
                    country.getName().getCommon() + " does not list German (deu).");
        }
    }

    /**
     * Test 5: Germany is in the German (deu) language response.
     */
    @Test(description = "Germany is present in German language results")
    public void testGermanyInGermanLanguage() {
        Response response = client.getCountriesByLanguage(TestData.LANGUAGE_DEU);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_LANGUAGE + TestData.LANGUAGE_DEU, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        boolean found = Arrays.stream(countries)
                .anyMatch(c -> "Germany".equals(c.getName().getCommon()));

        Assert.assertTrue(found, "Germany should be present in the German language results.");
    }

    /**
     * Test 6: Japan is in the Japanese (jpn) language response.
     */
    @Test(description = "Japan is present in Japanese language results")
    public void testJapanInJapaneseLanguage() {
        Response response = client.getCountriesByLanguage(TestData.LANGUAGE_JPN);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_LANGUAGE + TestData.LANGUAGE_JPN, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        boolean found = Arrays.stream(countries)
                .anyMatch(c -> "Japan".equals(c.getName().getCommon()));

        Assert.assertTrue(found, "Japan should be present in the Japanese language results.");
    }

    /**
     * Test 7: Portuguese (por) language results include Brazil.
     */
    @Test(description = "Brazil is present in Portuguese language results")
    public void testBrazilInPortugueseLanguage() {
        Response response = client.getCountriesByLanguage(TestData.LANGUAGE_POR);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_LANGUAGE + TestData.LANGUAGE_POR, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        boolean found = Arrays.stream(countries)
                .anyMatch(c -> "Brazil".equals(c.getName().getCommon()));

        Assert.assertTrue(found, "Brazil should be present in the Portuguese language results.");
    }

    /**
     * Test 8: South Africa's language map contains at least 11 official languages.
     * South Africa has 11 constitutionally recognised official languages.
     */
    @Test(description = "South Africa has at least 11 official languages")
    public void testSouthAfricaHas11OfficialLanguages() {
        Response response = client.getCountryNameAndLanguages(TestData.SOUTH_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_NAME + TestData.SOUTH_AFRICA + "?fields=name,languages",
                response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        int languageCount = countries[0].getLanguages().size();

        ResponseLogger.info(ExtentReportListener.getTest(),
                "South Africa language count: " + languageCount
                + " | Languages: " + countries[0].getLanguages());

        Assert.assertTrue(languageCount >= 11,
                "South Africa should have at least 11 languages. Actual: " + languageCount);
    }

    private static final String BASE_URL = "https://restcountries.com/v3.1";
}
