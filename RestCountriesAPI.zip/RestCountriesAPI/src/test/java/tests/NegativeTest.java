package tests;

import base.BaseTest;
import clients.CountryClient;
import data.Endpoints;
import data.TestData;
import io.restassured.response.Response;
import listeners.ExtentReportListener;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import utils.ResponseLogger;

/**
 * NegativeTest validates that the REST Countries API returns the correct
 * error responses for invalid inputs.
 *
 * Tests cover:
 *   - Invalid country name returns 404
 *   - Invalid country code returns 404
 *   - Invalid region returns 404
 *   - Invalid language code returns 404
 *   - Invalid currency code returns 404
 *
 * Negative tests are critical — they confirm the API handles bad input
 * gracefully rather than returning unexpected data or a 500 error.
 */
public class NegativeTest extends BaseTest {

    private CountryClient client;

    @BeforeClass
    public void init() {
        client = new CountryClient();
    }

    /**
     * Test 1: Invalid country name returns 404 Not Found.
     */
    @Test(description = "Invalid country name returns 404")
    public void testInvalidCountryNameReturns404() {
        Response response = client.getCountryByName(TestData.INVALID_COUNTRY);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_NAME + TestData.INVALID_COUNTRY, response);

        Assert.assertEquals(response.getStatusCode(), TestData.STATUS_NOT_FOUND,
                "Invalid country name should return 404. Actual: " + response.getStatusCode());

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Correctly returned 404 for: " + TestData.INVALID_COUNTRY);
    }

    /**
     * Test 2: Invalid country code returns 404 Not Found.
     */
    @Test(description = "Invalid country code returns 404")
    public void testInvalidCountryCodeReturns404() {
        Response response = client.getCountryByCode(TestData.CODE_INVALID);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_CODE + TestData.CODE_INVALID, response);

        Assert.assertEquals(response.getStatusCode(), TestData.STATUS_NOT_FOUND,
                "Invalid country code should return 404. Actual: " + response.getStatusCode());
    }

    /**
     * Test 3: Invalid region name returns 404 Not Found.
     */
    @Test(description = "Invalid region name returns 404")
    public void testInvalidRegionReturns404() {
        Response response = client.getCountriesByRegion(TestData.REGION_INVALID);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_REGION + TestData.REGION_INVALID, response);

        Assert.assertEquals(response.getStatusCode(), TestData.STATUS_NOT_FOUND,
                "Invalid region should return 404. Actual: " + response.getStatusCode());
    }

    /**
     * Test 4: Invalid language code returns 404 Not Found.
     */
    @Test(description = "Invalid language code returns 404")
    public void testInvalidLanguageCodeReturns404() {
        Response response = client.getCountriesByLanguage(TestData.LANGUAGE_INVALID);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_LANGUAGE + TestData.LANGUAGE_INVALID, response);

        Assert.assertEquals(response.getStatusCode(), TestData.STATUS_NOT_FOUND,
                "Invalid language code should return 404. Actual: " + response.getStatusCode());
    }

    /**
     * Test 5: Invalid currency code returns 404 Not Found.
     */
    @Test(description = "Invalid currency code returns 404")
    public void testInvalidCurrencyCodeReturns404() {
        Response response = client.getCountriesByCurrency(TestData.CURRENCY_INVALID);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_CURRENCY + TestData.CURRENCY_INVALID, response);

        Assert.assertEquals(response.getStatusCode(), TestData.STATUS_NOT_FOUND,
                "Invalid currency code should return 404. Actual: " + response.getStatusCode());
    }

    /**
     * Test 6: Empty name search does not return 200.
     * The API should either redirect or return a 404/400 for an empty path.
     */
    @Test(description = "Empty search string does not return 200")
    public void testEmptyNameSearchDoesNotReturn200() {
        Response response = client.getCountryByName("");

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_NAME, response);

        Assert.assertNotEquals(response.getStatusCode(), TestData.STATUS_OK,
                "Empty name search should not return 200.");

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Status for empty name search: " + response.getStatusCode());
    }

    /**
     * Test 7: Response body for a 404 contains a status field.
     * The API returns { "status": 404, "message": "Not Found" } on errors.
     */
    @Test(description = "404 response body contains status field")
    public void test404ResponseBodyContainsStatusField() {
        Response response = client.getCountryByName(TestData.INVALID_COUNTRY);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_NAME + TestData.INVALID_COUNTRY, response);

        Assert.assertEquals(response.getStatusCode(), TestData.STATUS_NOT_FOUND,
                "Expected 404 status code.");

        // The REST Countries API returns a JSON error body with a "status" field
        int statusInBody = response.jsonPath().getInt("status");
        Assert.assertEquals(statusInBody, TestData.STATUS_NOT_FOUND,
                "Error response body should contain status: 404.");

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Error body: " + response.getBody().asString());
    }

    private static final String BASE_URL = "https://restcountries.com/v3.1";
}
