package tests;

import base.BaseTest;
import clients.CountryClient;
import data.Endpoints;
import data.TestData;
import io.restassured.response.Response;
import listeners.ExtentReportListener;
import models.Country;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import utils.ResponseLogger;

import java.util.Arrays;

/**
 * RegionTest validates the /region and /subregion endpoints.
 *
 * Tests cover:
 *   - Region endpoints return non-empty arrays
 *   - Every country in the response belongs to the requested region
 *   - Specific countries are present within their expected region
 *   - Subregion filtering returns the correct subset
 */
public class RegionTest extends BaseTest {

    private CountryClient client;

    @BeforeClass
    public void init() {
        client = new CountryClient();
    }

    /**
     * Test 1: Africa region returns a non-empty list of countries.
     */
    @Test(description = "Africa region returns a non-empty list")
    public void testAfricaRegionReturnsCountries() {
        Response response = client.getCountriesByRegion(TestData.REGION_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_REGION + TestData.REGION_AFRICA, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        ResponseLogger.info(ExtentReportListener.getTest(),
                "African countries returned: " + countries.length);

        Assert.assertTrue(countries.length > 0,
                "Africa region should return at least one country.");
    }

    /**
     * Test 2: Every country returned for Africa has region = "Africa".
     */
    @Test(description = "Every country in Africa region has region = Africa")
    public void testAllAfricaCountriesHaveCorrectRegion() {
        Response response = client.getCountriesByRegion(TestData.REGION_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_REGION + TestData.REGION_AFRICA, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        for (Country country : countries) {
            Assert.assertEquals(country.getRegion(), TestData.REGION_AFRICA,
                    "Country '" + country.getName().getCommon()
                    + "' has wrong region: " + country.getRegion());
        }
    }

    /**
     * Test 3: South Africa is present in the Africa region response.
     */
    @Test(description = "South Africa is present in Africa region")
    public void testSouthAfricaInAfricaRegion() {
        Response response = client.getCountriesByRegion(TestData.REGION_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_REGION + TestData.REGION_AFRICA, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        boolean found = Arrays.stream(countries)
                .anyMatch(c -> TestData.SOUTH_AFRICA_FULL.equals(c.getName().getCommon()));

        Assert.assertTrue(found,
                "South Africa should be present in the Africa region response.");
    }

    /**
     * Test 4: Nigeria is present in the Africa region response.
     */
    @Test(description = "Nigeria is present in Africa region")
    public void testNigeriaInAfricaRegion() {
        Response response = client.getCountriesByRegion(TestData.REGION_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_REGION + TestData.REGION_AFRICA, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        boolean found = Arrays.stream(countries)
                .anyMatch(c -> "Nigeria".equals(c.getName().getCommon()));

        Assert.assertTrue(found, "Nigeria should be present in the Africa region.");
    }

    /**
     * Test 5: Europe region returns a non-empty list.
     */
    @Test(description = "Europe region returns a non-empty list")
    public void testEuropeRegionReturnsCountries() {
        Response response = client.getCountriesByRegion(TestData.REGION_EUROPE);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_REGION + TestData.REGION_EUROPE, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        ResponseLogger.info(ExtentReportListener.getTest(),
                "European countries returned: " + countries.length);

        Assert.assertTrue(countries.length > 0,
                "Europe region should return at least one country.");
    }

    /**
     * Test 6: Germany is present in the Europe region response.
     */
    @Test(description = "Germany is present in Europe region")
    public void testGermanyInEuropeRegion() {
        Response response = client.getCountriesByRegion(TestData.REGION_EUROPE);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_REGION + TestData.REGION_EUROPE, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        boolean found = Arrays.stream(countries)
                .anyMatch(c -> "Germany".equals(c.getName().getCommon()));

        Assert.assertTrue(found, "Germany should be present in the Europe region.");
    }

    /**
     * Test 7: Southern Africa subregion returns countries all in Southern Africa.
     */
    @Test(description = "Southern Africa subregion returns correct countries")
    public void testSouthernAfricaSubregion() {
        Response response = client.getCountriesBySubregion(TestData.SUBREGION_SOUTHERN_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_SUBREGION + TestData.SUBREGION_SOUTHERN_AFRICA, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        ResponseLogger.info(ExtentReportListener.getTest(),
                "Southern Africa countries: " + countries.length);

        Assert.assertTrue(countries.length > 0,
                "Southern Africa subregion should return at least one country.");

        for (Country country : countries) {
            Assert.assertEquals(country.getSubregion(), TestData.SUBREGION_SOUTHERN_AFRICA,
                    "Country '" + country.getName().getCommon()
                    + "' has wrong subregion: " + country.getSubregion());
        }
    }

    /**
     * Test 8: Asia region returns Japan.
     */
    @Test(description = "Japan is present in Asia region")
    public void testJapanInAsiaRegion() {
        Response response = client.getCountriesByRegion(TestData.REGION_ASIA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                BASE_URL + Endpoints.BY_REGION + TestData.REGION_ASIA, response);

        Country[] countries = response.then()
                .statusCode(TestData.STATUS_OK)
                .extract()
                .as(Country[].class);

        boolean found = Arrays.stream(countries)
                .anyMatch(c -> "Japan".equals(c.getName().getCommon()));

        Assert.assertTrue(found, "Japan should be present in the Asia region.");
    }

    private static final String BASE_URL = "https://restcountries.com/v3.1";
}
