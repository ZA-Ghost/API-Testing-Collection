package tests;

import base.BaseTest;
import clients.CountryClient;
import data.Endpoints;
import data.TestData;
import io.restassured.response.Response;
import listeners.ExtentReportListener;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import utils.ResponseLogger;

import java.io.File;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static org.testng.Assert.assertTrue;

/**
 * SchemaValidationTest validates that REST Countries API responses
 * conform to the expected JSON Schema definitions.
 *
 * Schema files are stored in src/test/resources/schemas/ and loaded
 * from the classpath using matchesJsonSchemaInClasspath().
 *
 * Schema validation catches structural breaking changes — a field
 * being removed, renamed, or changing type — before they break
 * the data assertions in other test classes.
 */
public class SchemaValidationTest extends BaseTest {

    private CountryClient client;

    @BeforeClass
    public void init() {
        client = new CountryClient();
    }

    /**
     * Test 1: All country names response matches the all-names schema.
     * Validates that every item in the array has a name object with
     * both common and official string fields.
     */
    @Test(description = "All country names response matches JSON Schema")
    public void testAllNamesSchemaValidation() {
        Response response = client.getAllCountryNames();

        ResponseLogger.log(ExtentReportListener.getTest(),
                TestData.BASE_URL + Endpoints.ALL_NAMES, response);

        response.then()
                .statusCode(TestData.STATUS_OK)
                .body(matchesJsonSchemaInClasspath(Endpoints.SCHEMA_ALL_NAMES));
    }

    /**
     * Test 2: Single country search response matches the single country schema.
     * Validates that South Africa's response contains all required top-level
     * fields with the correct types.
     */
    @Test(description = "Single country response matches JSON Schema")
    public void testSingleCountrySchemaValidation() {
        Response response = client.getCountryByName(TestData.SOUTH_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                TestData.BASE_URL + Endpoints.BY_NAME + TestData.SOUTH_AFRICA, response);

        response.then()
                .statusCode(TestData.STATUS_OK)
                .body(matchesJsonSchemaInClasspath(Endpoints.SCHEMA_SINGLE_COUNTRY));
    }

    /**
     * Test 3: Region search response is an array where every item has a name.
     * Validates the Africa region response structure.
     */
    @Test(description = "Region response matches JSON Schema")
    public void testRegionResponseSchemaValidation() {
        Response response = client.getCountriesByRegion(TestData.REGION_AFRICA);

        ResponseLogger.log(ExtentReportListener.getTest(),
                TestData.BASE_URL + Endpoints.BY_REGION + TestData.REGION_AFRICA, response);

        response.then()
                .statusCode(TestData.STATUS_OK)
                .body(matchesJsonSchemaInClasspath(Endpoints.SCHEMA_ALL_NAMES));
    }

    // Expose BASE_URL for ResponseLogger calls in this class
    private static final String BASE_URL = "https://restcountries.com/v3.1";
}
