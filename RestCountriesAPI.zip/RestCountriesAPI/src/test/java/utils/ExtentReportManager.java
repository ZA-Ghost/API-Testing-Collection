package utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

/**
 * ExtentReportManager is a singleton that creates and configures
 * the shared ExtentReports instance for the entire test run.
 *
 * All test classes write their results into one combined HTML report at:
 *   reports/ExtentReport.html
 *
 * Open it in any browser after the run — no server required.
 */
public class ExtentReportManager {

    private static ExtentReports extent;

    /**
     * Returns the shared ExtentReports instance, creating it on first call.
     *
     * @return The configured ExtentReports singleton
     */
    public static synchronized ExtentReports getInstance() {

        if (extent == null) {

            ExtentSparkReporter spark = new ExtentSparkReporter("reports/ExtentReport.html");
            spark.config().setDocumentTitle("REST Countries API Test Report");
            spark.config().setReportName("REST Countries API — Full Test Suite");
            spark.config().setTheme(Theme.DARK);
            spark.config().setTimeStampFormat("dd MMM yyyy HH:mm:ss");

            extent = new ExtentReports();
            extent.attachReporter(spark);

            // Environment panel shown at the top of the report
            extent.setSystemInfo("Project",     "REST Countries API Suite");
            extent.setSystemInfo("API Version", "v3.1");
            extent.setSystemInfo("Base URL",    "https://restcountries.com/v3.1");
            extent.setSystemInfo("Environment", "QA");
            extent.setSystemInfo("Tester",      "Khwezi");
        }

        return extent;
    }
}
