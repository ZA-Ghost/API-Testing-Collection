package utils;

import com.aventstack.extentreports.ExtentTest;
import io.restassured.response.Response;

/**
 * ResponseLogger formats and logs API request/response details
 * directly into the Extent HTML report for each test entry.
 *
 * Every test logs its request URL and the response status and body
 * so the report is self-contained — a reader can see exactly what
 * was called and what came back without re-running the test.
 */
public class ResponseLogger {

    /**
     * Logs the request URL and full response (status + body) to the
     * Extent report entry for the current test.
     *
     * @param test     The current ExtentTest entry to log into
     * @param url      The full request URL that was called
     * @param response The REST Assured response object
     */
    public static void log(ExtentTest test, String url, Response response) {
        test.info("<b>Request URL:</b> <code>" + url + "</code>");
        test.info("<b>Status Code:</b> " + response.getStatusCode());
        test.info("<b>Response Body:</b><pre>"
                + truncate(response.getBody().asPrettyString(), 1000)
                + "</pre>");
    }

    /**
     * Logs a plain informational message to the report entry.
     *
     * @param test    The current ExtentTest entry
     * @param message The message to log
     */
    public static void info(ExtentTest test, String message) {
        test.info(message);
    }

    /**
     * Truncates a string to a maximum length and appends "..." if cut.
     * Prevents very large response bodies from making the report unreadable.
     *
     * @param text      The string to truncate
     * @param maxLength Maximum number of characters to keep
     * @return The truncated string
     */
    private static String truncate(String text, int maxLength) {
        if (text == null) return "";
        return text.length() <= maxLength
                ? text
                : text.substring(0, maxLength) + "\n... [truncated]";
    }
}
